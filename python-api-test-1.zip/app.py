from flask import Flask, request
from database import *

app = Flask(__name__)


@app.route("/")
def home():
    return "Search '/users/' to list all users etc..."


@app.route("/users/", methods=["GET"])
def users():
    id = request.args.get("id")
    userId = request.args.get("userId")
    if id:
        user = user_by_id(id)
        return user
    elif userId:
        user = user_by_userid(userId)
        return user
    else:
        users = all_users()
        return users


@app.route("/create/", methods=["POST"])
def add_user():
    id = request.args.get("id")
    userId = request.args.get("userId")
    firstName = request.args.get("firstName")
    lastName = request.args.get("lastName")
    if id:
        new_user = get_new_user(id, userId, firstName, lastName)
        return container.create_item(body=new_user)


if __name__ == "__main__":
    app.run(debug=True)
