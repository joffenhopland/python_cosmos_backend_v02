import os

# for python_cosmos_sample.py
# settings = {
#     'host': os.environ.get('ACCOUNT_HOST', 'https://python-name.documents.azure.com:443/'),
#     'master_key': os.environ.get('ACCOUNT_KEY', 'IxT98FAznmC1pej7GCNTpXGwvYO2xRgIMHy5YKEJftoyWg2okgBAitAQDPUrJ0Wd8thRTA7RuLgHSQq8igeE5Q=='),
#     'database_id': os.environ.get('COSMOS_DATABASE', 'python_cosmos_db_test'),
#     'container_id': os.environ.get('COSMOS_CONTAINER', 'Items'),
# }


# for python_database_test
settings = {
    'url': os.environ.get('ACCOUNT_URL', 'https://python-name.documents.azure.com:443/'),
    'endpoint': os.environ.get('ACCOUNT_ENDPOINT', 'https://python-name.documents.azure.com:443/;AccountKey=IxT98FAznmC1pej7GCNTpXGwvYO2xRgIMHy5YKEJftoyWg2okgBAitAQDPUrJ0Wd8thRTA7RuLgHSQq8igeE5Q==;'),
    'master_key': os.environ.get('ACCOUNT_KEY', 'IxT98FAznmC1pej7GCNTpXGwvYO2xRgIMHy5YKEJftoyWg2okgBAitAQDPUrJ0Wd8thRTA7RuLgHSQq8igeE5Q=='),
    'database_name': os.environ.get('COSMOS_DATABASE', 'Contacts'),
    'container_name': os.environ.get('COSMOS_CONTAINER', 'Users'),
}
